function mostrarForm(){
	var LibroFormBox = document.getElementById("LibroForm");
	if(LibroFormBox.style.visibility == "hidden" || LibroFormBox.style.visibility == ""){
		LibroFormBox.style.visibility = "visible";
	}else{
		LibroFormBox.style.visibility = "hidden";
	}
	
}

function mostrarEditForm(){

}